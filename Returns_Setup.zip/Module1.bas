Attribute VB_Name = "Module1"
Option Explicit
Public BusyPrinting As Boolean
Private Const MAIN As Long = 1
Private Const CLIENTS As Long = 2
Private Const PRODUCTS As Long = 3
Private Const SETTINGS As Long = 4

Private Function WS(ByVal n As Long) As Worksheet
    Set WS = ThisWorkbook.Worksheets(n)
End Function

Private Function UI(ByVal n As Long) As String
    UI = CStr(ThisWorkbook.Worksheets("Help").Cells(n, 8).Value)
End Function

Private Function LastRow(ByVal sh As Worksheet, ByVal cols As Long) As Long
    Dim c As Long, r As Long
    LastRow = 1
    For c = 1 To cols
        r = sh.Cells(sh.Rows.Count, c).End(xlUp).Row
        If r > LastRow Then LastRow = r
    Next c
End Function

Private Function Normal(ByVal s As String) As String
    Dim i As Long
    s = LCase$(Trim$(s))
    s = Replace(s, ChrW(1571), ChrW(1575))
    s = Replace(s, ChrW(1573), ChrW(1575))
    s = Replace(s, ChrW(1570), ChrW(1575))
    s = Replace(s, ChrW(1609), ChrW(1610))
    s = Replace(s, ChrW(1577), ChrW(1607))
    s = Replace(s, ChrW(1600), "")
    For i = 1611 To 1618
        s = Replace(s, ChrW(i), "")
    Next i
    Normal = s
End Function

Private Function Matches(ByVal haystack As String, ByVal query As String) As Boolean
    Dim token As Variant
    haystack = Normal(haystack)
    For Each token In Split(Normal(query), " ")
        If Len(token) > 0 Then
            If InStr(1, haystack, CStr(token), vbTextCompare) = 0 Then Exit Function
        End If
    Next token
    Matches = True
End Function

Public Sub SearchProducts()
    Dim r As Long, sh As Worksheet
    Set sh = ThisWorkbook.Worksheets("ProductSearch")
    If ActiveSheet.Name = WS(MAIN).Name Then
        If ActiveCell.Row >= 15 And ActiveCell.Row <= 37 Then r = ActiveCell.Row
    End If
    If r = 0 Then
        For r = 15 To 37
            If Len(Trim$(CStr(WS(MAIN).Cells(r, 5).Value))) = 0 Then Exit For
        Next r
    End If
    If r > 37 Then
        MsgBox UI(2), vbInformation
        Exit Sub
    End If
    sh.Range("B4").Value = r
    sh.Activate
    RefreshSearch sh
    sh.Range("B3").Select
End Sub

Public Sub SearchClients()
    Dim sh As Worksheet
    Set sh = ThisWorkbook.Worksheets("ClientSearch")
    sh.Activate
    RefreshSearch sh
    sh.Range("B3").Select
End Sub

Public Sub RefreshSearch(ByVal sh As Worksheet)
    Dim src As Worksheet, nc As Long, n As Long, i As Long, j As Long
    Dim data As Variant, result() As Variant, count As Long, query As String
    Dim oldEvents As Boolean, lastResult As Long
    On Error GoTo Failed
    oldEvents = Application.EnableEvents
    Application.EnableEvents = False
    If sh.Name = "ProductSearch" Then
        Set src = WS(PRODUCTS): nc = 2
    ElseIf sh.Name = "ClientSearch" Then
        Set src = WS(CLIENTS): nc = 5
    Else
        GoTo Done
    End If
    lastResult = LastRow(sh, nc)
    If lastResult >= 7 Then sh.Range(sh.Cells(7, 1), sh.Cells(lastResult, nc)).ClearContents
    n = LastRow(src, nc)
    query = CStr(sh.Range("B3").Value)
    If n < 2 Then GoTo EmptyResult
    data = src.Range(src.Cells(2, 1), src.Cells(n, nc)).Value2
    For i = 1 To UBound(data, 1)
        If Len(CStr(data(i, 1))) > 0 And Len(CStr(data(i, 2))) > 0 Then
            If Matches(CStr(data(i, 2)) & " " & CStr(data(i, 1)), query) Then count = count + 1
        End If
    Next i
    If count = 0 Then GoTo EmptyResult
    ReDim result(1 To count, 1 To nc)
    count = 0
    For i = 1 To UBound(data, 1)
        If Len(CStr(data(i, 1))) > 0 And Len(CStr(data(i, 2))) > 0 Then
            If Matches(CStr(data(i, 2)) & " " & CStr(data(i, 1)), query) Then
                count = count + 1
                For j = 1 To nc
                    result(count, j) = data(i, j)
                Next j
            End If
        End If
    Next i
    sh.Range("A7").Resize(count, nc).Value2 = result
    sh.Range("A5").Value = UI(3) & " " & CStr(count) & " | " & UI(4)
    GoTo Done
EmptyResult:
    sh.Range("A5").Value = UI(5)
Done:
    Application.EnableEvents = oldEvents
    Exit Sub
Failed:
    Application.EnableEvents = oldEvents
    MsgBox UI(6) & vbCrLf & Err.Description, vbExclamation
End Sub

Public Sub PickResult(ByVal sh As Worksheet, ByVal rowNumber As Long)
    Dim dest As Range, r As Long, oldEvents As Boolean
    Dim src As Worksheet, code As String, i As Long, found As Long
    If rowNumber < 7 Then Exit Sub
    code = CStr(sh.Cells(rowNumber, 1).Value)
    If Len(code) = 0 Then Exit Sub
    If sh.Name = "ProductSearch" Then
        Set src = WS(PRODUCTS)
        If Not IsNumeric(sh.Range("B4").Value) Then
            MsgBox UI(7), vbExclamation: Exit Sub
        End If
        r = CLng(sh.Range("B4").Value)
        If r < 15 Or r > 37 Then
            MsgBox UI(7), vbExclamation: Exit Sub
        End If
        Set dest = WS(MAIN).Cells(r, 5)
    Else
        Set src = WS(CLIENTS)
        Set dest = WS(MAIN).Range("A9")
    End If
    For i = 2 To LastRow(src, 2)
        If CStr(src.Cells(i, 1).Value) = code Then found = found + 1
    Next i
    If found <> 1 Then
        RefreshSearch sh
        MsgBox UI(8), vbExclamation
        Exit Sub
    End If
    If Len(CStr(dest.Value)) > 0 And CStr(dest.Value) <> code Then
        If MsgBox(UI(9), vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    End If
    dest.NumberFormat = "@"
    dest.Value = code
    WS(MAIN).Calculate
    WS(MAIN).Activate
    If sh.Name = "ProductSearch" Then
        WS(MAIN).Cells(r, 7).Select
    Else
        WS(MAIN).Range("A9").Select
    End If
End Sub

Public Sub ReturnToForm()
    WS(MAIN).Activate
End Sub

Private Function NextNumber() As Long
    Dim sh As Worksheet, n As Long, suffix As String
    n = 1
    If IsNumeric(WS(SETTINGS).Range("D1").Value) Then
        If CDbl(WS(SETTINGS).Range("D1").Value) >= 1 Then n = CLng(WS(SETTINGS).Range("D1").Value)
    End If
    For Each sh In ThisWorkbook.Worksheets
        If Left$(sh.Name, 4) = "RET_" Then
            suffix = Mid$(sh.Name, 5)
            If IsNumeric(suffix) Then
                If CLng(suffix) >= n Then n = CLng(suffix) + 1
            End If
        End If
    Next sh
    NextNumber = n
End Function

Private Function ValidForm() As Boolean
    Dim r As Long, c As Long, total As Double, entries As Long, found As Long, i As Long
    Dim code As String, src As Worksheet
    code = CStr(WS(MAIN).Range("A9").Value)
    If Len(code) = 0 Then MsgBox UI(10), vbExclamation: Exit Function
    Set src = WS(CLIENTS)
    For i = 2 To LastRow(src, 5)
        If CStr(src.Cells(i, 1).Value) = code And Len(CStr(src.Cells(i, 2).Value)) > 0 Then found = found + 1
    Next i
    If found <> 1 Then MsgBox UI(8), vbExclamation: Exit Function
    Set src = WS(PRODUCTS)
    For r = 15 To 37
        code = Trim$(CStr(WS(MAIN).Cells(r, 5).Value))
        If Len(code) > 0 Then
            entries = entries + 1
            found = 0
            For i = 2 To LastRow(src, 2)
                If CStr(src.Cells(i, 1).Value) = code And Len(CStr(src.Cells(i, 2).Value)) > 0 Then found = found + 1
            Next i
            If found <> 1 Then MsgBox UI(11) & " " & r, vbExclamation: Exit Function
            total = 0
            For c = 7 To 9
                If Len(CStr(WS(MAIN).Cells(r, c).Value)) > 0 Then
                    If Not IsNumeric(WS(MAIN).Cells(r, c).Value) Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    If CDbl(WS(MAIN).Cells(r, c).Value) < 0 Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    If CDbl(WS(MAIN).Cells(r, c).Value) <> Fix(CDbl(WS(MAIN).Cells(r, c).Value)) Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    total = total + CDbl(WS(MAIN).Cells(r, c).Value)
                End If
            Next c
            If total = 0 Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
        Else
            If Application.CountA(WS(MAIN).Range("B" & r & ":D" & r)) > 0 Or Application.CountA(WS(MAIN).Range("J" & r)) > 0 Or Application.CountA(WS(MAIN).Range("L" & r & ":M" & r)) > 0 Then
                MsgBox UI(11) & " " & r, vbExclamation: Exit Function
            End If
            For c = 7 To 9
                If Len(CStr(WS(MAIN).Cells(r, c).Value)) > 0 Then
                    If Not IsNumeric(WS(MAIN).Cells(r, c).Value) Then MsgBox UI(11) & " " & r, vbExclamation: Exit Function
                    If CDbl(WS(MAIN).Cells(r, c).Value) <> 0 Then MsgBox UI(11) & " " & r, vbExclamation: Exit Function
                End If
            Next c
        End If
    Next r
    If entries = 0 Then MsgBox UI(13), vbExclamation: Exit Function
    ValidForm = True
End Function

Public Sub ArchiveAndPrint()
    Dim form As Worksheet, snapshot As Worksheet, log As Worksheet
    Dim n As Long, logRow As Long, archiveName As String, shapeIndex As Long
    Dim oldEvents As Boolean, oldAlerts As Boolean, archiveSaved As Boolean
    Dim errorText As String, archived As Boolean, cell As Range
    If BusyPrinting Then Exit Sub
    oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts
    On Error GoTo Failed
    Set form = WS(MAIN)
    If ThisWorkbook.ReadOnly Then MsgBox UI(14), vbExclamation: Exit Sub
    If Len(ThisWorkbook.Path) = 0 Then MsgBox UI(15), vbExclamation: Exit Sub
    If Not ValidForm() Then Exit Sub
    If MsgBox(UI(16), vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    If Not Application.Dialogs(xlDialogPrinterSetup).Show Then Exit Sub
    BusyPrinting = True
    Application.EnableEvents = False
    n = NextNumber()
    archiveName = "RET_" & Format$(n, "000000")
    WS(SETTINGS).Range("D1").Value = n
    form.Calculate
    form.Copy After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count)
    Set snapshot = ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count)
    snapshot.Name = archiveName
    snapshot.Tab.Color = RGB(38, 135, 100)
    snapshot.Range("A1:M38").Copy
    snapshot.Range("A1:M38").PasteSpecial xlPasteValues
    Application.CutCopyMode = False
    snapshot.Range("I7").Value = Now
    snapshot.Range("I7").NumberFormat = "yyyy-mm-dd hh:mm"
    snapshot.Range("L9").Value = "#" & CStr(n)
    For shapeIndex = snapshot.Shapes.Count To 1 Step -1
        If Left$(snapshot.Shapes(shapeIndex).Name, 4) = "btn_" Or snapshot.Shapes(shapeIndex).Type = msoFormControl Then snapshot.Shapes(shapeIndex).Delete
    Next shapeIndex
    snapshot.Range("A11:M11").ClearContents
    snapshot.Cells.Locked = True
    snapshot.Protect Password:="", DrawingObjects:=True, Contents:=True, Scenarios:=True
    Set log = ThisWorkbook.Worksheets("Archive")
    logRow = LastRow(log, 9) + 1
    If logRow < 4 Then logRow = 4
    log.Cells(logRow, 1).Value = n
    log.Cells(logRow, 2).Value = Now
    log.Cells(logRow, 3).NumberFormat = "@"
    log.Cells(logRow, 3).Value = form.Range("A9").Value
    log.Cells(logRow, 4).Value = form.Range("B9").Value
    log.Cells(logRow, 5).Value = form.Range("J9").Value
    log.Cells(logRow, 6).Value = form.Range("G38").Value
    log.Cells(logRow, 7).Value = form.Range("H38").Value
    log.Cells(logRow, 8).Value = form.Range("I38").Value
    log.Cells(logRow, 9).Value = UI(17)
    log.Hyperlinks.Add Anchor:=log.Cells(logRow, 10), Address:="", SubAddress:="'" & archiveName & "'!A1", TextToDisplay:=archiveName
    ThisWorkbook.Save
    archiveSaved = True
    form.Range("A9").MergeArea.ClearContents
    form.Range("D12").MergeArea.ClearContents
    form.Range("B15:E37,G15:J37,L15:M37").ClearContents
    WS(SETTINGS).Range("D1").Value = n + 1
    form.Calculate
    form.Activate
    ThisWorkbook.Save
    On Error GoTo PrintFailed
    snapshot.PrintOut Copies:=1
    log.Cells(logRow, 9).Value = UI(18)
    ThisWorkbook.Save
    Application.EnableEvents = oldEvents
    BusyPrinting = False
    form.Activate
    MsgBox UI(19) & " " & archiveName & vbCrLf & UI(20), vbInformation
    Exit Sub
PrintFailed:
    errorText = Err.Description
    On Error Resume Next
    log.Cells(logRow, 9).Value = UI(21)
    ThisWorkbook.Save
    Application.EnableEvents = oldEvents
    BusyPrinting = False
    form.Activate
    On Error GoTo 0
    MsgBox UI(22) & " " & archiveName & vbCrLf & errorText, vbExclamation
    Exit Sub
Failed:
    errorText = Err.Description
    On Error Resume Next
    If Not archiveSaved Then
        Application.DisplayAlerts = False
        If Not snapshot Is Nothing Then snapshot.Delete
        If logRow >= 4 Then log.Rows(logRow).Delete
    End If
    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents
    BusyPrinting = False
    If Not form Is Nothing Then form.Activate
    On Error GoTo 0
    If archiveSaved Then
        MsgBox UI(23) & " " & archiveName & vbCrLf & errorText, vbExclamation
    Else
        MsgBox UI(24) & vbCrLf & errorText, vbExclamation
    End If
End Sub

Public Sub ReprintArchive()
    Dim log As Worksheet, archiveName As String, sh As Worksheet
    Dim oldEvents As Boolean, errorText As String
    Set log = ThisWorkbook.Worksheets("Archive")
    If ActiveSheet.Name <> log.Name Or ActiveCell.Row < 4 Then MsgBox UI(25), vbInformation: Exit Sub
    archiveName = CStr(log.Cells(ActiveCell.Row, 10).Value)
    If Len(archiveName) = 0 Then Exit Sub
    On Error GoTo Failed
    Set sh = ThisWorkbook.Worksheets(archiveName)
    If Not Application.Dialogs(xlDialogPrinterSetup).Show Then Exit Sub
    oldEvents = Application.EnableEvents
    Application.EnableEvents = False
    BusyPrinting = True
    sh.PrintOut Copies:=1
    Application.EnableEvents = oldEvents
    BusyPrinting = False
    log.Cells(ActiveCell.Row, 9).Value = UI(18)
    ThisWorkbook.Save
    Exit Sub
Failed:
    errorText = Err.Description
    If BusyPrinting Then Application.EnableEvents = oldEvents
    BusyPrinting = False
    MsgBox UI(26) & vbCrLf & errorText, vbExclamation
End Sub

Public Sub HandleChange(ByVal sh As Object, ByVal target As Range)
    If sh.Name = "ProductSearch" Or sh.Name = "ClientSearch" Then
        If Not Intersect(target, sh.Range("B3:E3")) Is Nothing Then RefreshSearch sh
    ElseIf sh.Name = WS(CLIENTS).Name Or sh.Name = WS(PRODUCTS).Name Then
        WS(MAIN).Calculate
    End If
End Sub

Public Sub HandleDoubleClick(ByVal sh As Object, ByVal target As Range, ByRef cancel As Boolean)
    If sh.Name = "ProductSearch" Or sh.Name = "ClientSearch" Then
        If target.Row >= 7 And target.Column <= 5 Then
            cancel = True
            PickResult sh, target.Row
        End If
    ElseIf sh.Name = "Archive" Then
        If target.Row >= 4 And target.Column = 9 Then
            cancel = True
            ReprintArchive
        End If
    ElseIf sh.Name = WS(MAIN).Name Then
        If Not Intersect(target, sh.Range("J11:K11")) Is Nothing Then
            cancel = True
            ArchiveAndPrint
        ElseIf Not Intersect(target, sh.Range("A9:D10")) Is Nothing Then
            cancel = True
            SearchClients
        ElseIf Not Intersect(target, sh.Range("A12:M12")) Is Nothing Then
            cancel = True
            SearchProducts
        End If
    End If
End Sub

Public Sub Initialize()
    Dim oldEvents As Boolean
    oldEvents = Application.EnableEvents
    On Error GoTo Done
    Application.EnableEvents = False
    WS(SETTINGS).Range("D1").Value = NextNumber()
    WS(MAIN).Calculate
Done:
    Application.EnableEvents = oldEvents
End Sub
