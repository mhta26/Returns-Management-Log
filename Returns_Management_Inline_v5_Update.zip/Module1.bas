Attribute VB_Name = "Module1"
Option Explicit
Public BusyPrinting As Boolean
Private Const MAIN As Long = 1
Private Const CLIENTS As Long = 2
Private Const PRODUCTS As Long = 3
Private Const SETTINGS As Long = 4

Private Function WS(ByVal n As Long) As Worksheet
    Set WS = ThisWorkbook.Worksheets(n)
End Function

Private Function UI(ByVal n As Long) As String
    UI = CStr(WS(SETTINGS).Cells(n, 8).Value)
End Function

Private Function LastRow(ByVal Sh As Worksheet, ByVal cols As Long) As Long
    Dim c As Long, r As Long
    LastRow = 1
    For c = 1 To cols
        r = Sh.Cells(Sh.Rows.count, c).End(xlUp).Row
        If r > LastRow Then LastRow = r
    Next c
End Function

Private Function Normal(ByVal s As String) As String
    Dim i As Long
    s = LCase$(Trim$(s))
    s = Replace(s, ChrW(1571), ChrW(1575))
    s = Replace(s, ChrW(1573), ChrW(1575))
    s = Replace(s, ChrW(1570), ChrW(1575))
    s = Replace(s, ChrW(1609), ChrW(1610))
    s = Replace(s, ChrW(1577), ChrW(1607))
    s = Replace(s, ChrW(1600), "")
    For i = 1611 To 1618
        s = Replace(s, ChrW(i), "")
    Next i
    Normal = s
End Function

Private Function Matches(ByVal haystack As String, ByVal query As String) As Boolean
    Dim token As Variant
    haystack = Normal(haystack)
    For Each token In Split(Normal(query), " ")
        If Len(token) > 0 Then
            If InStr(1, haystack, CStr(token), vbTextCompare) = 0 Then Exit Function
        End If
    Next token
    Matches = True
End Function

Private Function CodeRow(ByVal src As Worksheet, ByVal code As String) As Long
    Dim r As Long, found As Long
    If Len(code) = 0 Then Exit Function
    For r = 2 To LastRow(src, 2)
        If CStr(src.Cells(r, 1).Value2) = code And Len(CStr(src.Cells(r, 2).Value2)) > 0 Then
            If found > 0 Then CodeRow = -1: Exit Function
            found = r
        End If
    Next r
    CodeRow = found
End Function

Private Function CellText(ByVal cell As Range) As String
    If IsError(cell.Value2) Then
        CellText = "#ERROR"
    Else
        CellText = Trim$(Replace(Replace(CStr(cell.Value2), ChrW(160), " "), vbTab, " "))
    End If
End Function

Private Sub FormRows(ByRef firstRow As Long, ByRef totalRow As Long)
    Dim r As Long, lastLabelRow As Long, title As String, header As Range
    firstRow = 0: totalRow = 0
    lastLabelRow = WS(MAIN).Cells(WS(MAIN).Rows.Count, 1).End(xlUp).Row
    For r = 1 To lastLabelRow
        title = Normal(CellText(WS(MAIN).Cells(r, 1)))
        If title = Normal(UI(31)) Then
            If totalRow <> 0 Then Err.Raise vbObjectError + 901, "FormRows", UI(29)
            totalRow = r
        End If
    Next r
    If totalRow = 0 Then Err.Raise vbObjectError + 902, "FormRows", UI(29)
    For r = 1 To totalRow - 1
        If Normal(CellText(WS(MAIN).Cells(r, 5))) = Normal(UI(30)) Then
            Set header = WS(MAIN).Cells(r, 5).MergeArea
            firstRow = header.Row + header.Rows.Count
            Exit For
        End If
    Next r
    If firstRow = 0 Or firstRow >= totalRow Then Err.Raise vbObjectError + 903, "FormRows", UI(29)
End Sub

Private Function FirstItemRow() As Long
    Dim firstRow As Long, totalRow As Long
    FormRows firstRow, totalRow
    FirstItemRow = firstRow
End Function

Private Function LastItemRow() As Long
    Dim firstRow As Long, totalRow As Long
    FormRows firstRow, totalRow
    LastItemRow = totalRow - 1
End Function

Private Function ItemCells(ByVal firstCol As Long, ByVal lastCol As Long) As Range
    Dim firstRow As Long, totalRow As Long
    FormRows firstRow, totalRow
    Set ItemCells = WS(MAIN).Range(WS(MAIN).Cells(firstRow, firstCol), WS(MAIN).Cells(totalRow - 1, lastCol))
End Function

Private Function RowHasData(ByVal r As Long) As Boolean
    Dim c As Long, value As String
    For c = 2 To 13
        If c <> 11 Then
            value = CellText(WS(MAIN).Cells(r, c))
            If Len(value) > 0 Then
                If c >= 7 And c <= 9 Then
                    If Not IsNumeric(value) Then RowHasData = True: Exit Function
                    If CDbl(value) <> 0 Then RowHasData = True: Exit Function
                Else
                    RowHasData = True
                    Exit Function
                End If
            End If
        End If
    Next c
End Function

Private Function HasList(ByVal cell As Range) As Boolean
    On Error Resume Next
    HasList = (cell.Validation.Type = xlValidateList)
    On Error GoTo 0
End Function

Private Sub EnsureItemRows(ByVal firstRow As Long, ByVal totalRow As Long)
    Dim r As Long, template As String
    For r = firstRow To totalRow - 1
        If WS(MAIN).Cells(r, 11).HasFormula Then
            template = WS(MAIN).Cells(r, 11).FormulaR1C1
            Exit For
        End If
    Next r
    If Len(template) = 0 Then template = UI(37)
    For r = firstRow To totalRow - 1
        WS(MAIN).Cells(r, 1).Value2 = r - firstRow + 1
        If Not WS(MAIN).Cells(r, 11).HasFormula And Len(CellText(WS(MAIN).Cells(r, 11))) = 0 Then
            WS(MAIN).Cells(r, 11).FormulaR1C1 = template
        End If
        If Not HasList(WS(MAIN).Cells(r, 5)) Then SetList WS(MAIN).Cells(r, 5), "InlineProducts"
        If Not HasList(WS(MAIN).Cells(r, 6)) Then SetList WS(MAIN).Cells(r, 6), "InlineProducts"
    Next r
End Sub

Private Sub RefreshTotals(ByVal firstRow As Long, ByVal totalRow As Long)
    Dim c As Long
    EnsureItemRows firstRow, totalRow
    For c = 7 To 9
        WS(MAIN).Cells(totalRow, c).Formula = "=SUM(" & WS(MAIN).Range(WS(MAIN).Cells(firstRow, c), WS(MAIN).Cells(totalRow - 1, c)).Address(False, False) & ")"
    Next c
    WS(MAIN).Range("J9").Formula = "=SUMPRODUCT(--(" & WS(MAIN).Range(WS(MAIN).Cells(firstRow, 5), WS(MAIN).Cells(totalRow - 1, 5)).Address(False, False) & "<>""""))"
    WS(MAIN).PageSetup.PrintArea = WS(MAIN).Range("A1:M" & totalRow).Address
    WS(MAIN).Calculate
End Sub

Private Function HasTopSearch() As Boolean
    HasTopSearch = (WS(MAIN).Range("D12").MergeArea.Address = "$D$12:$E$12" And WS(MAIN).Range("G12").MergeArea.Address = "$G$12:$M$12")
End Function

Private Function SearchInputCells() As Range
    Set SearchInputCells = Application.Union(WS(MAIN).Range("A9,B9"), ItemCells(5, 6))
    If HasTopSearch() Then Set SearchInputCells = Application.Union(SearchInputCells, WS(MAIN).Range("D12,G12"))
End Function

Private Function ProductSearchTarget() As Range
    Dim row As Long
    If HasTopSearch() Then
        Set ProductSearchTarget = WS(MAIN).Range("G12")
        Exit Function
    End If
    For row = FirstItemRow() To LastItemRow()
        If Len(CellText(WS(MAIN).Cells(row, 5))) = 0 And Len(CellText(WS(MAIN).Cells(row, 6))) = 0 Then
            Set ProductSearchTarget = WS(MAIN).Cells(row, 6)
            Exit Function
        End If
    Next row
    Set ProductSearchTarget = WS(MAIN).Cells(FirstItemRow(), 6)
End Function

Private Sub RepairTableHeadings(ByVal firstRow As Long)
    Dim headerRow As Long
    If HasTopSearch() Then Exit Sub
    headerRow = WS(MAIN).Cells(firstRow - 1, 5).MergeArea.Row
    If Len(CellText(WS(MAIN).Cells(headerRow, 4))) = 0 Then WS(MAIN).Cells(headerRow, 4).Value2 = UI(47)
    If Len(CellText(WS(MAIN).Cells(headerRow, 7))) = 0 Then WS(MAIN).Cells(headerRow, 7).Value2 = UI(48)
    If HasList(WS(MAIN).Range("D12")) Then WS(MAIN).Range("D12").MergeArea.Validation.Delete
    If HasList(WS(MAIN).Range("G12")) Then WS(MAIN).Range("G12").MergeArea.Validation.Delete
End Sub

Private Function IsClientCell(ByVal dest As Range) As Boolean
    IsClientCell = (dest.Row = 9 And (dest.Column = 1 Or dest.Column = 2))
End Function

Private Function CandidateSource(ByVal customer As Boolean) As Worksheet
    If customer Then Set CandidateSource = WS(CLIENTS) Else Set CandidateSource = WS(PRODUCTS)
End Function

Private Sub SetList(ByVal dest As Range, ByVal listName As String)
    With dest.MergeArea.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertInformation, Operator:=xlBetween, Formula1:="=" & listName
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = False
        .ShowInput = True
        .InputTitle = UI(28)
        .InputMessage = Left$(UI(4), 255)
    End With
End Sub

Private Function BuildList(ByVal customer As Boolean, ByVal query As String) As Long
    Dim src As Worksheet, data As Variant, result() As Variant
    Dim i As Long, n As Long, count As Long, c As Long, oldLast As Long, listName As String
    Set src = CandidateSource(customer)
    If customer Then c = 27: listName = "InlineClients" Else c = 28: listName = "InlineProducts"
    With WS(MAIN)
        oldLast = .Cells(.Rows.Count, c).End(xlUp).Row
        If oldLast >= 2 Then .Range(.Cells(2, c), .Cells(oldLast, c)).ClearContents
    End With
    n = LastRow(src, 2)
    If n >= 2 Then
        data = src.Range("A2:B" & n).Value2
        For i = 1 To UBound(data, 1)
            If Len(CStr(data(i, 1))) > 0 And Len(CStr(data(i, 2))) > 0 Then
                If Matches(CStr(data(i, 2)) & " " & CStr(data(i, 1)), query) Then count = count + 1
            End If
        Next i
        If count > 0 Then
            ReDim result(1 To count, 1 To 1)
            count = 0
            For i = 1 To UBound(data, 1)
                If Len(CStr(data(i, 1))) > 0 And Len(CStr(data(i, 2))) > 0 Then
                    If Matches(CStr(data(i, 2)) & " " & CStr(data(i, 1)), query) Then
                        count = count + 1
                        result(count, 1) = Left$(CStr(data(i, 2)), 220) & " | " & CStr(data(i, 1))
                    End If
                End If
            Next i
            WS(MAIN).Cells(2, c).Resize(count, 1).Value2 = result
        End If
    End If
    If count = 0 Then WS(MAIN).Cells(2, c).Value = UI(5)
    On Error Resume Next
    ThisWorkbook.Names(listName).Delete
    On Error GoTo 0
    ThisWorkbook.Names.Add Name:=listName, RefersTo:="='" & Replace(WS(MAIN).Name, "'", "''") & "'!" & WS(MAIN).Cells(2, c).Resize(IIf(count > 0, count, 1), 1).Address
    WS(MAIN).Range("AA:AB").EntireColumn.Hidden = True
    BuildList = count
End Function

Private Sub ShowList(ByVal dest As Range)
    dest.Select
    If ActiveSheet.Name = WS(MAIN).Name Then Application.SendKeys "%{DOWN}", False
End Sub

Private Sub FillNames()
    Dim r As Long, found As Long
    found = CodeRow(WS(CLIENTS), CStr(WS(MAIN).Range("A9").Value2))
    If found > 0 Then WS(MAIN).Range("B9").Value = WS(CLIENTS).Cells(found, 2).Value2
    If HasTopSearch() Then
        found = CodeRow(WS(PRODUCTS), CStr(WS(MAIN).Range("D12").Value2))
        If found > 0 Then WS(MAIN).Range("G12").Value = WS(PRODUCTS).Cells(found, 2).Value2
    End If
    For r = FirstItemRow() To LastItemRow()
        found = CodeRow(WS(PRODUCTS), CStr(WS(MAIN).Cells(r, 5).Value2))
        If found > 0 Then WS(MAIN).Cells(r, 6).Value = WS(PRODUCTS).Cells(found, 2).Value2
    Next r
End Sub

Private Sub ApplyChoice(ByVal dest As Range, ByVal sourceRow As Long)
    Dim customer As Boolean, src As Worksheet, r As Long
    customer = IsClientCell(dest)
    Set src = CandidateSource(customer)
    If customer Then
        WS(MAIN).Range("A9").NumberFormat = "@"
        WS(MAIN).Range("A9").Value = CStr(src.Cells(sourceRow, 1).Value2)
        WS(MAIN).Range("B9").Value = src.Cells(sourceRow, 2).Value2
    ElseIf HasTopSearch() And dest.Row = 12 Then
        WS(MAIN).Range("D12").NumberFormat = "@"
        WS(MAIN).Range("D12").Value = CStr(src.Cells(sourceRow, 1).Value2)
        WS(MAIN).Range("G12").Value = src.Cells(sourceRow, 2).Value2
        For r = FirstItemRow() To LastItemRow()
            If Len(CStr(WS(MAIN).Cells(r, 5).Value2)) = 0 And Len(CStr(WS(MAIN).Cells(r, 6).Value2)) = 0 Then Exit For
        Next r
        If r > LastItemRow() Then
            MsgBox UI(2), vbInformation
        Else
            WS(MAIN).Cells(r, 5).NumberFormat = "@"
            WS(MAIN).Cells(r, 5).Value = CStr(src.Cells(sourceRow, 1).Value2)
            WS(MAIN).Cells(r, 6).Value = src.Cells(sourceRow, 2).Value2
            WS(MAIN).Cells(r, 7).Select
        End If
    Else
        r = dest.Row
        WS(MAIN).Cells(r, 5).NumberFormat = "@"
        WS(MAIN).Cells(r, 5).Value = CStr(src.Cells(sourceRow, 1).Value2)
        WS(MAIN).Cells(r, 6).Value = src.Cells(sourceRow, 2).Value2
        WS(MAIN).Cells(r, 7).Select
    End If
    WS(MAIN).Calculate
End Sub

Private Sub SearchChanged(ByVal dest As Range)
    Dim customer As Boolean, src As Worksheet, query As String, code As String
    Dim p As Long, found As Long, count As Long, c As Long, listName As String
    customer = IsClientCell(dest)
    Set src = CandidateSource(customer)
    query = Trim$(CStr(dest.Value2))
    If customer Then c = 27: listName = "InlineClients" Else c = 28: listName = "InlineProducts"
    If customer Then
        If dest.Column = 2 Then WS(MAIN).Range("A9").MergeArea.ClearContents Else WS(MAIN).Range("B9").MergeArea.ClearContents
    ElseIf HasTopSearch() And dest.Row = 12 Then
        If dest.Column = 7 Then WS(MAIN).Range("D12").MergeArea.ClearContents Else WS(MAIN).Range("G12").MergeArea.ClearContents
    Else
        If dest.Column = 6 Then WS(MAIN).Cells(dest.Row, 5).ClearContents Else WS(MAIN).Cells(dest.Row, 6).ClearContents
    End If
    If Len(query) = 0 Then
        BuildList customer, ""
        SetList dest, listName
        Exit Sub
    End If
    code = query
    p = InStrRev(query, " | ")
    If p > 0 Then code = Mid$(query, p + 3)
    found = CodeRow(src, code)
    If found = -1 Then MsgBox UI(8), vbExclamation: Exit Sub
    If found > 0 Then
        ApplyChoice dest, found
        Exit Sub
    End If
    count = BuildList(customer, query)
    SetList dest, listName
    If count = 0 Then
        MsgBox UI(5), vbInformation
    ElseIf count = 1 Then
        code = CStr(WS(MAIN).Cells(2, c).Value2)
        code = Mid$(code, InStrRev(code, " | ") + 3)
        found = CodeRow(src, code)
        If found > 0 Then ApplyChoice dest, found Else MsgBox UI(8), vbExclamation
    Else
        ShowList dest
    End If
End Sub

Private Sub StartSearch(ByVal dest As Range)
    Dim oldEvents As Boolean, listName As String, customer As Boolean
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    Application.EnableEvents = False
    customer = IsClientCell(dest)
    If customer Then listName = "InlineClients" Else listName = "InlineProducts"
    BuildList customer, ""
    SetList dest, listName
    ShowList dest
Done:
    Application.EnableEvents = oldEvents
    Exit Sub
Failed:
    MsgBox UI(6) & vbCrLf & Err.Description, vbExclamation
    Resume Done
End Sub

Public Sub SearchProducts()
    If ActiveSheet.Name <> WS(MAIN).Name Then Exit Sub
    If ActiveCell.Row >= FirstItemRow() And ActiveCell.Row <= LastItemRow() And (ActiveCell.Column = 5 Or ActiveCell.Column = 6) Then
        StartSearch WS(MAIN).Cells(ActiveCell.Row, 6)
    Else
        StartSearch ProductSearchTarget()
    End If
End Sub

Public Sub SearchClients()
    If ActiveSheet.Name = WS(MAIN).Name Then StartSearch WS(MAIN).Range("B9")
End Sub

Public Sub HandleChange(ByVal Sh As Object, ByVal Target As Range)
    Dim oldEvents As Boolean, dest As Range, firstRow As Long, totalRow As Long
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    Application.EnableEvents = False
    If Sh.Name = WS(MAIN).Name Then
        FormRows firstRow, totalRow
        If Not Intersect(Target, Sh.Range(Sh.Cells(firstRow, 1), Sh.Cells(totalRow, 13))) Is Nothing Then RefreshTotals firstRow, totalRow
        Set dest = Target.Cells(1, 1)
        If Target.CountLarge > 1 And Target.Address <> dest.MergeArea.Address Then GoTo Done
        If Not Intersect(dest, SearchInputCells()) Is Nothing Then SearchChanged dest
    ElseIf Sh.Name = WS(CLIENTS).Name Or Sh.Name = WS(PRODUCTS).Name Then
        FillNames
        BuildList True, ""
        BuildList False, ""
        WS(MAIN).Calculate
    End If
Done:
    Application.EnableEvents = oldEvents
    Exit Sub
Failed:
    MsgBox UI(6) & vbCrLf & Err.Description, vbExclamation
    Resume Done
End Sub

Public Sub HandleDoubleClick(ByVal Sh As Object, ByVal Target As Range, ByRef Cancel As Boolean)
    If Sh.Name = WS(MAIN).Name Then
        If Not Intersect(Target, Sh.Range("J11:K11")) Is Nothing Then
            Cancel = True
            ArchiveAndPrint
        ElseIf Not Intersect(Target, Sh.Range("A9:D10")) Is Nothing Then
            Cancel = True
            SearchClients
        ElseIf HasTopSearch() And Not Intersect(Target, Sh.Range("A12:M12")) Is Nothing Then
            Cancel = True
            StartSearch ProductSearchTarget()
        ElseIf Not Intersect(Target, ItemCells(5, 6)) Is Nothing Then
            Cancel = True
            StartSearch WS(MAIN).Cells(Target.Row, 6)
        End If
    ElseIf IsSavedReceiptSheet(Sh.Name) Then
        If Not Intersect(Target, Sh.Range("J11:K11")) Is Nothing Then
            Cancel = True
            ReprintSavedSheet Sh.Name
        End If
    ElseIf Sh.Name = "Archive" Then
        If Target.Row >= 4 And Target.Column = 9 Then
            Cancel = True
            ReprintArchive
        End If
    End If
End Sub

Public Sub Initialize()
    Dim oldEvents As Boolean, r As Long, firstRow As Long, totalRow As Long
    oldEvents = Application.EnableEvents
    On Error GoTo Done
    Application.EnableEvents = False
    FormRows firstRow, totalRow
    RepairTableHeadings firstRow
    RefreshTotals firstRow, totalRow
    WS(SETTINGS).Range("D1").Value = NextNumber()
    FillNames
    BuildList True, ""
    BuildList False, ""
    SetList WS(MAIN).Range("A9"), "InlineClients"
    SetList WS(MAIN).Range("B9"), "InlineClients"
    If HasTopSearch() Then
        SetList WS(MAIN).Range("D12"), "InlineProducts"
        SetList WS(MAIN).Range("G12"), "InlineProducts"
    End If
    For r = FirstItemRow() To LastItemRow()
        SetList WS(MAIN).Cells(r, 5), "InlineProducts"
        SetList WS(MAIN).Cells(r, 6), "InlineProducts"
    Next r
    WS(MAIN).Calculate
Done:
    Application.EnableEvents = oldEvents
End Sub

Private Function NextNumber() As Long
    Dim Sh As Worksheet, n As Long, suffix As String, log As Worksheet, row As Long
    n = 1
    If IsNumeric(WS(SETTINGS).Range("D1").Value) Then
        If CDbl(WS(SETTINGS).Range("D1").Value) >= 1 Then n = CLng(WS(SETTINGS).Range("D1").Value)
    End If
    For Each Sh In ThisWorkbook.Worksheets
        If Left$(Sh.Name, 4) = "RET_" Then
            suffix = Mid$(Sh.Name, 5)
            If IsNumeric(suffix) Then
                If CLng(suffix) >= n Then n = CLng(suffix) + 1
            End If
        End If
    Next Sh
    Set log = ThisWorkbook.Worksheets("Archive")
    For row = 4 To LastRow(log, 10)
        If IsNumeric(log.Cells(row, 1).Value2) Then
            If CDbl(log.Cells(row, 1).Value2) >= n Then n = CLng(log.Cells(row, 1).Value2) + 1
        End If
    Next row
    NextNumber = n
End Function

Private Function ValidForm() As Boolean
    Dim r As Long, c As Long, firstRow As Long, totalRow As Long
    Dim quantity As Double, entries As Long, code As String, value As String
    code = CellText(WS(MAIN).Range("A9"))
    If Len(code) = 0 Then MsgBox UI(10), vbExclamation: Exit Function
    If CodeRow(WS(CLIENTS), code) <= 0 Then MsgBox UI(8), vbExclamation: Exit Function
    FormRows firstRow, totalRow
    For r = firstRow To totalRow - 1
        If RowHasData(r) Then
            code = CellText(WS(MAIN).Cells(r, 5))
            If Len(code) = 0 Then MsgBox UI(11) & " " & r, vbExclamation: Exit Function
            If CodeRow(WS(PRODUCTS), code) <= 0 Then MsgBox UI(11) & " " & r, vbExclamation: Exit Function
            entries = entries + 1
            quantity = 0
            For c = 7 To 9
                value = CellText(WS(MAIN).Cells(r, c))
                If Len(value) > 0 Then
                    If Not IsNumeric(value) Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    If CDbl(value) < 0 Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    If CDbl(value) <> Fix(CDbl(value)) Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    quantity = quantity + CDbl(value)
                End If
            Next c
            If quantity = 0 Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
        End If
    Next r
    If entries = 0 Then MsgBox UI(13), vbExclamation: Exit Function
    ValidForm = True
End Function

Private Function ReceiptFileName(ByVal number As Long) As String
    Dim baseName As String, suffix As String, bad As Variant, i As Long
    baseName = ThisWorkbook.Name
    If InStrRev(baseName, ".") > 0 Then suffix = LCase$(Mid$(baseName, InStrRev(baseName, ".")))
    If suffix = ".xlsm" Or suffix = ".xlsx" Or suffix = ".xlsb" Or suffix = ".xls" Then baseName = Left$(baseName, InStrRev(baseName, ".") - 1)
    For Each bad In Array("\", "/", ":", "*", "?", Chr$(34), "<", ">", "|")
        baseName = Replace(baseName, CStr(bad), "_")
    Next bad
    For i = 0 To 31
        baseName = Replace(baseName, Chr$(i), " ")
    Next i
    baseName = Trim$(baseName)
    Do While Len(baseName) > 0
        If Right$(baseName, 1) = "." Or Right$(baseName, 1) = " " Then baseName = Left$(baseName, Len(baseName) - 1) Else Exit Do
    Loop
    If Len(baseName) = 0 Then baseName = UI(38)
    ReceiptFileName = Left$(baseName, 160) & " - " & CStr(number) & ".pdf"
End Function

Private Function PDFPrinterSelected() As Boolean
    PDFPrinterSelected = (InStr(1, Application.ActivePrinter, "PDF", vbTextCompare) > 0)
End Function

Private Function FolderPath() As String
    If Len(ThisWorkbook.Path) = 0 Or InStr(1, ThisWorkbook.Path, "://", vbTextCompare) > 0 Then Err.Raise vbObjectError + 920, "FolderPath", UI(49)
    FolderPath = ThisWorkbook.Path
    If Right$(FolderPath, 1) <> Application.PathSeparator Then FolderPath = FolderPath & Application.PathSeparator
End Function

Private Function FileExists(ByVal path As String) As Boolean
    FileExists = (Len(Dir$(path, vbNormal Or vbHidden Or vbSystem Or vbReadOnly Or vbArchive)) > 0)
End Function

Public Function IsSavedReceiptSheet(ByVal sheetName As String) As Boolean
    Dim suffix As String
    If Left$(sheetName, 4) <> "RET_" Then Exit Function
    suffix = Mid$(sheetName, 5)
    If Len(suffix) = 0 Then Exit Function
    If IsNumeric(suffix) Then IsSavedReceiptSheet = (CDbl(suffix) > 0)
End Function

Private Sub CloseReceiptCopy(ByRef temporary As Workbook)
    On Error Resume Next
    Application.CutCopyMode = False
    If Not temporary Is Nothing Then temporary.Close SaveChanges:=False
    Set temporary = Nothing
    On Error GoTo 0
End Sub

Private Sub PrepareReceiptCopy(ByVal number As Long, ByVal totalRow As Long, ByRef temporary As Workbook, ByRef receipt As Worksheet)
    Dim address As String, i As Long
    address = "A1:M" & totalRow
    WS(MAIN).Calculate
    WS(MAIN).Copy
    Set temporary = Application.ActiveWorkbook
    Set receipt = temporary.Worksheets(1)
    receipt.Range(address).Copy
    receipt.Range(address).PasteSpecial xlPasteValues
    Application.CutCopyMode = False
    receipt.Range("I7").Value = Now
    receipt.Range("L9").Value = "#" & CStr(number)
    receipt.Range("A11:M11").ClearContents
    receipt.Range("AA:AB").ClearContents
    receipt.Range(address).Validation.Delete
    For i = receipt.Shapes.Count To 1 Step -1
        If Left$(receipt.Shapes(i).Name, 4) = "btn_" Or receipt.Shapes(i).Type = msoFormControl Then receipt.Shapes(i).Delete
    Next i
    receipt.PageSetup.PrintArea = receipt.Range(address).Address
End Sub

Private Sub ExportReceiptPDF(ByVal receipt As Worksheet, ByVal path As String)
    receipt.ExportAsFixedFormat Type:=xlTypePDF, fileName:=path, Quality:=xlQualityStandard, IncludeDocProperties:=True, IgnorePrintAreas:=False, OpenAfterPublish:=False
    If Not FileExists(path) Then Err.Raise vbObjectError + 921, "ExportReceiptPDF", UI(56)
End Sub

Public Sub ArchiveAndPrint()
    Dim form As Worksheet, log As Worksheet, receipt As Worksheet, temporary As Workbook
    Dim firstRow As Long, totalRow As Long, number As Long, logRow As Long
    Dim pdfPath As String, relativeName As String, paper As Boolean, errorText As String, paperError As String
    Dim oldEvents As Boolean, oldScreen As Boolean, oldCounter As Variant
    Dim itemBackup As Variant, noteBackup As Variant, clientCode As Variant, clientName As Variant, topCode As Variant, topName As Variant
    Dim backupReady As Boolean, resetStarted As Boolean, pdfSaved As Boolean, committed As Boolean
    If BusyPrinting Then Exit Sub
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    On Error GoTo Failed
    Set form = WS(MAIN)
    Set log = ThisWorkbook.Worksheets("Archive")
    If ThisWorkbook.ReadOnly Then MsgBox UI(14), vbExclamation: Exit Sub
    pdfPath = FolderPath()
    FormRows firstRow, totalRow
    RepairTableHeadings firstRow
    RefreshTotals firstRow, totalRow
    If Not ValidForm() Then Exit Sub
    If MsgBox(UI(16), vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    If Not Application.Dialogs(xlDialogPrinterSetup).Show Then Exit Sub
    paper = Not PDFPrinterSelected()
    number = NextNumber()
    Do While FileExists(pdfPath & ReceiptFileName(number))
        number = number + 1
    Loop
    relativeName = ReceiptFileName(number)
    pdfPath = pdfPath & relativeName
    ' Keep a durable filled-in copy until the PDF is successfully exported.
    ThisWorkbook.Save
    oldCounter = WS(SETTINGS).Range("D1").Value2
    itemBackup = form.Range(form.Cells(firstRow, 2), form.Cells(totalRow - 1, 10)).Formula
    noteBackup = form.Range(form.Cells(firstRow, 12), form.Cells(totalRow - 1, 13)).Formula
    clientCode = form.Range("A9").Formula
    clientName = form.Range("B9").Formula
    If HasTopSearch() Then
        topCode = form.Range("D12").Formula
        topName = form.Range("G12").Formula
    End If
    backupReady = True
    BusyPrinting = True
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    WS(SETTINGS).Range("D1").Value2 = number
    form.Calculate
    PrepareReceiptCopy number, totalRow, temporary, receipt
    ExportReceiptPDF receipt, pdfPath
    pdfSaved = True
    logRow = LastRow(log, 10) + 1
    If logRow < 4 Then logRow = 4
    log.Cells(logRow, 1).Value2 = number
    log.Cells(logRow, 2).Value = Now
    log.Cells(logRow, 2).NumberFormat = "yyyy-mm-dd hh:mm"
    log.Cells(logRow, 3).NumberFormat = "@"
    log.Cells(logRow, 3).Value2 = CStr(form.Range("A9").Value2)
    log.Cells(logRow, 4).Value2 = form.Range("B9").Value2
    log.Cells(logRow, 5).Value2 = form.Range("J9").Value2
    log.Cells(logRow, 6).Value2 = form.Cells(totalRow, 7).Value2
    log.Cells(logRow, 7).Value2 = form.Cells(totalRow, 8).Value2
    log.Cells(logRow, 8).Value2 = form.Cells(totalRow, 9).Value2
    log.Cells(logRow, 9).Value2 = UI(42)
    log.Hyperlinks.Add Anchor:=log.Cells(logRow, 10), Address:=relativeName, TextToDisplay:=relativeName
    resetStarted = True
    form.Range("A9").MergeArea.ClearContents
    form.Range("B9").MergeArea.ClearContents
    If HasTopSearch() Then
        form.Range("D12").MergeArea.ClearContents
        form.Range("G12").MergeArea.ClearContents
    End If
    form.Range(form.Cells(firstRow, 2), form.Cells(totalRow - 1, 10)).ClearContents
    form.Range(form.Cells(firstRow, 12), form.Cells(totalRow - 1, 13)).ClearContents
    WS(SETTINGS).Range("D1").Value2 = number + 1
    BuildList True, ""
    BuildList False, ""
    RefreshTotals firstRow, totalRow
    form.Activate
    ThisWorkbook.Save
    committed = True
    If paper Then
        On Error Resume Next
        receipt.PrintOut Copies:=1
        If Err.Number <> 0 Then paperError = Err.Description
        Err.Clear
        On Error GoTo Failed
        If Len(paperError) = 0 Then log.Cells(logRow, 9).Value2 = UI(45) Else log.Cells(logRow, 9).Value2 = UI(46)
        On Error Resume Next
        ThisWorkbook.Save
        On Error GoTo Failed
    End If
    CloseReceiptCopy temporary
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    BusyPrinting = False
    form.Activate
    If Len(paperError) > 0 Then
        MsgBox UI(46) & vbCrLf & pdfPath & vbCrLf & paperError & vbCrLf & UI(20), vbExclamation
    Else
        MsgBox UI(51) & vbCrLf & pdfPath & vbCrLf & UI(20), vbInformation
    End If
    Exit Sub
Failed:
    errorText = Err.Description
    On Error Resume Next
    If Not committed And backupReady Then
        If resetStarted Then
            form.Range(form.Cells(firstRow, 2), form.Cells(totalRow - 1, 10)).Formula = itemBackup
            form.Range(form.Cells(firstRow, 12), form.Cells(totalRow - 1, 13)).Formula = noteBackup
            form.Range("A9").Formula = clientCode
            form.Range("B9").Formula = clientName
            If HasTopSearch() Then
                form.Range("D12").Formula = topCode
                form.Range("G12").Formula = topName
            End If
        End If
        WS(SETTINGS).Range("D1").Value2 = oldCounter
        If logRow >= 4 Then log.Range(log.Cells(logRow, 1), log.Cells(logRow, 10)).Clear
        form.Calculate
    End If
    CloseReceiptCopy temporary
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    BusyPrinting = False
    If Not form Is Nothing Then form.Activate
    On Error GoTo 0
    If committed Then
        MsgBox UI(46) & vbCrLf & pdfPath & vbCrLf & errorText & vbCrLf & UI(20), vbExclamation
    ElseIf pdfSaved Then
        MsgBox UI(52) & vbCrLf & pdfPath & vbCrLf & errorText, vbExclamation
    Else
        MsgBox UI(56) & vbCrLf & errorText, vbExclamation
    End If
End Sub

Private Sub OpenLogPDF(ByVal row As Long, Optional ByVal legacyName As String = "")
    Dim log As Worksheet, address As String, path As String, number As Long
    Dim receipt As Worksheet, oldEvents As Boolean, oldBusy As Boolean, errorText As String
    oldEvents = Application.EnableEvents
    oldBusy = BusyPrinting
    On Error GoTo Failed
    Set log = ThisWorkbook.Worksheets("Archive")
    If row < 4 Then Err.Raise vbObjectError + 922, "OpenLogPDF", UI(54)
    number = CLng(log.Cells(row, 1).Value2)
    If log.Cells(row, 10).Hyperlinks.Count > 0 Then address = log.Cells(row, 10).Hyperlinks(1).Address
    If Len(address) > 0 Then
        If LCase$(Right$(address, 4)) <> ".pdf" Then Err.Raise vbObjectError + 925, "OpenLogPDF", UI(54)
        path = address
        If InStr(1, path, ":", vbTextCompare) = 0 And Left$(path, 2) <> "\\" Then path = FolderPath() & path
        If Not FileExists(path) Then Err.Raise vbObjectError + 923, "OpenLogPDF", UI(53)
    Else
        If Len(legacyName) = 0 Then legacyName = CStr(log.Cells(row, 10).Value2)
        If Not IsSavedReceiptSheet(legacyName) Then Err.Raise vbObjectError + 924, "OpenLogPDF", UI(54)
        Set receipt = ThisWorkbook.Worksheets(legacyName)
        address = ReceiptFileName(number)
        path = FolderPath() & address
        Application.EnableEvents = False
        BusyPrinting = True
        If Not FileExists(path) Then ExportReceiptPDF receipt, path
        If Not ThisWorkbook.ReadOnly Then
            log.Cells(row, 10).Hyperlinks.Delete
            log.Hyperlinks.Add Anchor:=log.Cells(row, 10), Address:=address, TextToDisplay:=address
            log.Cells(row, 9).Value2 = UI(42)
            ThisWorkbook.Save
        End If
    End If
    Application.EnableEvents = oldEvents
    BusyPrinting = oldBusy
    ThisWorkbook.FollowHyperlink Address:=path, NewWindow:=True
    Exit Sub
Failed:
    errorText = Err.Description
    Application.EnableEvents = oldEvents
    BusyPrinting = oldBusy
    MsgBox UI(26) & vbCrLf & errorText, vbExclamation
End Sub

Public Sub ReprintArchive()
    Dim log As Worksheet
    Set log = ThisWorkbook.Worksheets("Archive")
    If ActiveSheet.Name <> log.Name Or ActiveCell.Row < 4 Then MsgBox UI(25), vbInformation: Exit Sub
    OpenLogPDF ActiveCell.Row
End Sub

Public Sub ReprintSavedSheet(ByVal sheetName As String)
    Dim log As Worksheet, row As Long, number As Long
    If Not IsSavedReceiptSheet(sheetName) Then Exit Sub
    On Error GoTo Failed
    number = CLng(Mid$(sheetName, 5))
    Set log = ThisWorkbook.Worksheets("Archive")
    For row = 4 To LastRow(log, 10)
        If IsNumeric(log.Cells(row, 1).Value2) Then
            If CLng(log.Cells(row, 1).Value2) = number Then
                OpenLogPDF row, sheetName
                Exit Sub
            End If
        End If
    Next row
    MsgBox UI(54), vbExclamation
    Exit Sub
Failed:
    MsgBox UI(26) & vbCrLf & Err.Description, vbExclamation
End Sub
