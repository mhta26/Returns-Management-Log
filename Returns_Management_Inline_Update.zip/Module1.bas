Attribute VB_Name = "Module1"
Option Explicit
Public BusyPrinting As Boolean
Private Const MAIN As Long = 1
Private Const CLIENTS As Long = 2
Private Const PRODUCTS As Long = 3
Private Const SETTINGS As Long = 4

Private Function WS(ByVal n As Long) As Worksheet
    Set WS = ThisWorkbook.Worksheets(n)
End Function

Private Function UI(ByVal n As Long) As String
    UI = CStr(WS(SETTINGS).Cells(n, 8).Value)
End Function

Private Function LastRow(ByVal Sh As Worksheet, ByVal cols As Long) As Long
    Dim c As Long, r As Long
    LastRow = 1
    For c = 1 To cols
        r = Sh.Cells(Sh.Rows.count, c).End(xlUp).Row
        If r > LastRow Then LastRow = r
    Next c
End Function

Private Function Normal(ByVal s As String) As String
    Dim i As Long
    s = LCase$(Trim$(s))
    s = Replace(s, ChrW(1571), ChrW(1575))
    s = Replace(s, ChrW(1573), ChrW(1575))
    s = Replace(s, ChrW(1570), ChrW(1575))
    s = Replace(s, ChrW(1609), ChrW(1610))
    s = Replace(s, ChrW(1577), ChrW(1607))
    s = Replace(s, ChrW(1600), "")
    For i = 1611 To 1618
        s = Replace(s, ChrW(i), "")
    Next i
    Normal = s
End Function

Private Function Matches(ByVal haystack As String, ByVal query As String) As Boolean
    Dim token As Variant
    haystack = Normal(haystack)
    For Each token In Split(Normal(query), " ")
        If Len(token) > 0 Then
            If InStr(1, haystack, CStr(token), vbTextCompare) = 0 Then Exit Function
        End If
    Next token
    Matches = True
End Function

Private Function CodeRow(ByVal src As Worksheet, ByVal code As String) As Long
    Dim r As Long, found As Long
    If Len(code) = 0 Then Exit Function
    For r = 2 To LastRow(src, 2)
        If CStr(src.Cells(r, 1).Value2) = code And Len(CStr(src.Cells(r, 2).Value2)) > 0 Then
            If found > 0 Then CodeRow = -1: Exit Function
            found = r
        End If
    Next r
    CodeRow = found
End Function

Private Function IsClientCell(ByVal dest As Range) As Boolean
    IsClientCell = (dest.Row = 9 And (dest.Column = 1 Or dest.Column = 2))
End Function

Private Function CandidateSource(ByVal customer As Boolean) As Worksheet
    If customer Then Set CandidateSource = WS(CLIENTS) Else Set CandidateSource = WS(PRODUCTS)
End Function

Private Sub SetList(ByVal dest As Range, ByVal listName As String)
    With dest.MergeArea.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertInformation, Operator:=xlBetween, Formula1:="=" & listName
        .IgnoreBlank = True
        .InCellDropdown = True
        .ShowError = False
        .ShowInput = True
        .InputTitle = UI(28)
        .InputMessage = Left$(UI(4), 255)
    End With
End Sub

Private Function BuildList(ByVal customer As Boolean, ByVal query As String) As Long
    Dim src As Worksheet, data As Variant, result() As Variant
    Dim i As Long, n As Long, count As Long, c As Long, oldLast As Long, listName As String
    Set src = CandidateSource(customer)
    If customer Then c = 27: listName = "InlineClients" Else c = 28: listName = "InlineProducts"
    With WS(MAIN)
        oldLast = .Cells(.Rows.Count, c).End(xlUp).Row
        If oldLast >= 2 Then .Range(.Cells(2, c), .Cells(oldLast, c)).ClearContents
    End With
    n = LastRow(src, 2)
    If n >= 2 Then
        data = src.Range("A2:B" & n).Value2
        For i = 1 To UBound(data, 1)
            If Len(CStr(data(i, 1))) > 0 And Len(CStr(data(i, 2))) > 0 Then
                If Matches(CStr(data(i, 2)) & " " & CStr(data(i, 1)), query) Then count = count + 1
            End If
        Next i
        If count > 0 Then
            ReDim result(1 To count, 1 To 1)
            count = 0
            For i = 1 To UBound(data, 1)
                If Len(CStr(data(i, 1))) > 0 And Len(CStr(data(i, 2))) > 0 Then
                    If Matches(CStr(data(i, 2)) & " " & CStr(data(i, 1)), query) Then
                        count = count + 1
                        result(count, 1) = Left$(CStr(data(i, 2)), 220) & " | " & CStr(data(i, 1))
                    End If
                End If
            Next i
            WS(MAIN).Cells(2, c).Resize(count, 1).Value2 = result
        End If
    End If
    If count = 0 Then WS(MAIN).Cells(2, c).Value = UI(5)
    On Error Resume Next
    ThisWorkbook.Names(listName).Delete
    On Error GoTo 0
    ThisWorkbook.Names.Add Name:=listName, RefersTo:="='" & Replace(WS(MAIN).Name, "'", "''") & "'!" & WS(MAIN).Cells(2, c).Resize(IIf(count > 0, count, 1), 1).Address
    WS(MAIN).Range("AA:AB").EntireColumn.Hidden = True
    BuildList = count
End Function

Private Sub ShowList(ByVal dest As Range)
    dest.Select
    If ActiveSheet.Name = WS(MAIN).Name Then Application.SendKeys "%{DOWN}", False
End Sub

Private Sub FillNames()
    Dim r As Long, found As Long
    found = CodeRow(WS(CLIENTS), CStr(WS(MAIN).Range("A9").Value2))
    If found > 0 Then WS(MAIN).Range("B9").Value = WS(CLIENTS).Cells(found, 2).Value2
    found = CodeRow(WS(PRODUCTS), CStr(WS(MAIN).Range("D12").Value2))
    If found > 0 Then WS(MAIN).Range("G12").Value = WS(PRODUCTS).Cells(found, 2).Value2
    For r = 15 To 37
        found = CodeRow(WS(PRODUCTS), CStr(WS(MAIN).Cells(r, 5).Value2))
        If found > 0 Then WS(MAIN).Cells(r, 6).Value = WS(PRODUCTS).Cells(found, 2).Value2
    Next r
End Sub

Private Sub ApplyChoice(ByVal dest As Range, ByVal sourceRow As Long)
    Dim customer As Boolean, src As Worksheet, r As Long
    customer = IsClientCell(dest)
    Set src = CandidateSource(customer)
    If customer Then
        WS(MAIN).Range("A9").NumberFormat = "@"
        WS(MAIN).Range("A9").Value = CStr(src.Cells(sourceRow, 1).Value2)
        WS(MAIN).Range("B9").Value = src.Cells(sourceRow, 2).Value2
    ElseIf dest.Row = 12 Then
        WS(MAIN).Range("D12").NumberFormat = "@"
        WS(MAIN).Range("D12").Value = CStr(src.Cells(sourceRow, 1).Value2)
        WS(MAIN).Range("G12").Value = src.Cells(sourceRow, 2).Value2
        For r = 15 To 37
            If Len(CStr(WS(MAIN).Cells(r, 5).Value2)) = 0 And Len(CStr(WS(MAIN).Cells(r, 6).Value2)) = 0 Then Exit For
        Next r
        If r > 37 Then
            MsgBox UI(2), vbInformation
        Else
            WS(MAIN).Cells(r, 5).NumberFormat = "@"
            WS(MAIN).Cells(r, 5).Value = CStr(src.Cells(sourceRow, 1).Value2)
            WS(MAIN).Cells(r, 6).Value = src.Cells(sourceRow, 2).Value2
            WS(MAIN).Cells(r, 7).Select
        End If
    Else
        r = dest.Row
        WS(MAIN).Cells(r, 5).NumberFormat = "@"
        WS(MAIN).Cells(r, 5).Value = CStr(src.Cells(sourceRow, 1).Value2)
        WS(MAIN).Cells(r, 6).Value = src.Cells(sourceRow, 2).Value2
        WS(MAIN).Cells(r, 7).Select
    End If
    WS(MAIN).Calculate
End Sub

Private Sub SearchChanged(ByVal dest As Range)
    Dim customer As Boolean, src As Worksheet, query As String, code As String
    Dim p As Long, found As Long, count As Long, c As Long, listName As String
    customer = IsClientCell(dest)
    Set src = CandidateSource(customer)
    query = Trim$(CStr(dest.Value2))
    If customer Then c = 27: listName = "InlineClients" Else c = 28: listName = "InlineProducts"
    If customer Then
        If dest.Column = 2 Then WS(MAIN).Range("A9").MergeArea.ClearContents Else WS(MAIN).Range("B9").MergeArea.ClearContents
    ElseIf dest.Row = 12 Then
        If dest.Column = 7 Then WS(MAIN).Range("D12").MergeArea.ClearContents Else WS(MAIN).Range("G12").MergeArea.ClearContents
    Else
        If dest.Column = 6 Then WS(MAIN).Cells(dest.Row, 5).ClearContents Else WS(MAIN).Cells(dest.Row, 6).ClearContents
    End If
    If Len(query) = 0 Then
        BuildList customer, ""
        SetList dest, listName
        Exit Sub
    End If
    code = query
    p = InStrRev(query, " | ")
    If p > 0 Then code = Mid$(query, p + 3)
    found = CodeRow(src, code)
    If found = -1 Then MsgBox UI(8), vbExclamation: Exit Sub
    If found > 0 Then
        ApplyChoice dest, found
        Exit Sub
    End If
    count = BuildList(customer, query)
    SetList dest, listName
    If count = 0 Then
        MsgBox UI(5), vbInformation
    ElseIf count = 1 Then
        code = CStr(WS(MAIN).Cells(2, c).Value2)
        code = Mid$(code, InStrRev(code, " | ") + 3)
        found = CodeRow(src, code)
        If found > 0 Then ApplyChoice dest, found Else MsgBox UI(8), vbExclamation
    Else
        ShowList dest
    End If
End Sub

Private Sub StartSearch(ByVal dest As Range)
    Dim oldEvents As Boolean, listName As String, customer As Boolean
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    Application.EnableEvents = False
    customer = IsClientCell(dest)
    If customer Then listName = "InlineClients" Else listName = "InlineProducts"
    BuildList customer, ""
    SetList dest, listName
    ShowList dest
Done:
    Application.EnableEvents = oldEvents
    Exit Sub
Failed:
    MsgBox UI(6) & vbCrLf & Err.Description, vbExclamation
    Resume Done
End Sub

Public Sub SearchProducts()
    If ActiveSheet.Name <> WS(MAIN).Name Then Exit Sub
    If ActiveCell.Row >= 15 And ActiveCell.Row <= 37 And (ActiveCell.Column = 5 Or ActiveCell.Column = 6) Then
        StartSearch WS(MAIN).Cells(ActiveCell.Row, 6)
    Else
        StartSearch WS(MAIN).Range("G12")
    End If
End Sub

Public Sub SearchClients()
    If ActiveSheet.Name = WS(MAIN).Name Then StartSearch WS(MAIN).Range("B9")
End Sub

Public Sub HandleChange(ByVal Sh As Object, ByVal Target As Range)
    Dim oldEvents As Boolean, dest As Range
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    Application.EnableEvents = False
    If Sh.Name = WS(MAIN).Name Then
        Set dest = Target.Cells(1, 1)
        If Target.CountLarge > 1 And Target.Address <> dest.MergeArea.Address Then GoTo Done
        If Not Intersect(dest, Sh.Range("A9,B9,D12,G12,E15:F37")) Is Nothing Then SearchChanged dest
    ElseIf Sh.Name = WS(CLIENTS).Name Or Sh.Name = WS(PRODUCTS).Name Then
        FillNames
        BuildList True, ""
        BuildList False, ""
        WS(MAIN).Calculate
    End If
Done:
    Application.EnableEvents = oldEvents
    Exit Sub
Failed:
    MsgBox UI(6) & vbCrLf & Err.Description, vbExclamation
    Resume Done
End Sub

Public Sub HandleDoubleClick(ByVal Sh As Object, ByVal Target As Range, ByRef Cancel As Boolean)
    If Sh.Name = WS(MAIN).Name Then
        If Not Intersect(Target, Sh.Range("J11:K11")) Is Nothing Then
            Cancel = True
            ArchiveAndPrint
        ElseIf Not Intersect(Target, Sh.Range("A9:D10")) Is Nothing Then
            Cancel = True
            SearchClients
        ElseIf Not Intersect(Target, Sh.Range("A12:M12")) Is Nothing Then
            Cancel = True
            StartSearch WS(MAIN).Range("G12")
        ElseIf Not Intersect(Target, Sh.Range("E15:F37")) Is Nothing Then
            Cancel = True
            StartSearch WS(MAIN).Cells(Target.Row, 6)
        End If
    ElseIf Sh.Name = "Archive" Then
        If Target.Row >= 4 And Target.Column = 9 Then
            Cancel = True
            ReprintArchive
        End If
    End If
End Sub

Public Sub Initialize()
    Dim oldEvents As Boolean, r As Long
    oldEvents = Application.EnableEvents
    On Error GoTo Done
    Application.EnableEvents = False
    WS(SETTINGS).Range("D1").Value = NextNumber()
    FillNames
    BuildList True, ""
    BuildList False, ""
    SetList WS(MAIN).Range("A9"), "InlineClients"
    SetList WS(MAIN).Range("B9"), "InlineClients"
    SetList WS(MAIN).Range("D12"), "InlineProducts"
    SetList WS(MAIN).Range("G12"), "InlineProducts"
    For r = 15 To 37
        SetList WS(MAIN).Cells(r, 5), "InlineProducts"
        SetList WS(MAIN).Cells(r, 6), "InlineProducts"
    Next r
    WS(MAIN).Calculate
Done:
    Application.EnableEvents = oldEvents
End Sub

Private Function NextNumber() As Long
    Dim Sh As Worksheet, n As Long, suffix As String
    n = 1
    If IsNumeric(WS(SETTINGS).Range("D1").Value) Then
        If CDbl(WS(SETTINGS).Range("D1").Value) >= 1 Then n = CLng(WS(SETTINGS).Range("D1").Value)
    End If
    For Each Sh In ThisWorkbook.Worksheets
        If Left$(Sh.Name, 4) = "RET_" Then
            suffix = Mid$(Sh.Name, 5)
            If IsNumeric(suffix) Then
                If CLng(suffix) >= n Then n = CLng(suffix) + 1
            End If
        End If
    Next Sh
    NextNumber = n
End Function

Private Function ValidForm() As Boolean
    Dim r As Long, c As Long, total As Double, entries As Long, found As Long, i As Long
    Dim code As String, src As Worksheet
    code = CStr(WS(MAIN).Range("A9").Value)
    If Len(code) = 0 Then MsgBox UI(10), vbExclamation: Exit Function
    Set src = WS(CLIENTS)
    For i = 2 To LastRow(src, 5)
        If CStr(src.Cells(i, 1).Value) = code And Len(CStr(src.Cells(i, 2).Value)) > 0 Then found = found + 1
    Next i
    If found <> 1 Then MsgBox UI(8), vbExclamation: Exit Function
    Set src = WS(PRODUCTS)
    For r = 15 To 37
        code = Trim$(CStr(WS(MAIN).Cells(r, 5).Value))
        If Len(code) > 0 Then
            entries = entries + 1
            found = 0
            For i = 2 To LastRow(src, 2)
                If CStr(src.Cells(i, 1).Value) = code And Len(CStr(src.Cells(i, 2).Value)) > 0 Then found = found + 1
            Next i
            If found <> 1 Then MsgBox UI(11) & " " & r, vbExclamation: Exit Function
            total = 0
            For c = 7 To 9
                If Len(CStr(WS(MAIN).Cells(r, c).Value)) > 0 Then
                    If Not IsNumeric(WS(MAIN).Cells(r, c).Value) Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    If CDbl(WS(MAIN).Cells(r, c).Value) < 0 Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    If CDbl(WS(MAIN).Cells(r, c).Value) <> Fix(CDbl(WS(MAIN).Cells(r, c).Value)) Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
                    total = total + CDbl(WS(MAIN).Cells(r, c).Value)
                End If
            Next c
            If total = 0 Then MsgBox UI(12) & " " & r, vbExclamation: Exit Function
        Else
            If Len(CStr(WS(MAIN).Cells(r, 6).Value)) > 0 Or Application.CountA(WS(MAIN).Range("B" & r & ":D" & r)) > 0 Or Application.CountA(WS(MAIN).Range("J" & r)) > 0 Or Application.CountA(WS(MAIN).Range("L" & r & ":M" & r)) > 0 Then
                MsgBox UI(11) & " " & r, vbExclamation: Exit Function
            End If
            For c = 7 To 9
                If Len(CStr(WS(MAIN).Cells(r, c).Value)) > 0 Then
                    If Not IsNumeric(WS(MAIN).Cells(r, c).Value) Then MsgBox UI(11) & " " & r, vbExclamation: Exit Function
                    If CDbl(WS(MAIN).Cells(r, c).Value) <> 0 Then MsgBox UI(11) & " " & r, vbExclamation: Exit Function
                End If
            Next c
        End If
    Next r
    If entries = 0 Then MsgBox UI(13), vbExclamation: Exit Function
    ValidForm = True
End Function

Public Sub ArchiveAndPrint()
    Dim form As Worksheet, snapshot As Worksheet, log As Worksheet
    Dim n As Long, logRow As Long, archiveName As String, shapeIndex As Long
    Dim oldEvents As Boolean, oldAlerts As Boolean, archiveSaved As Boolean
    Dim errorText As String, archived As Boolean, cell As Range
    If BusyPrinting Then Exit Sub
    oldEvents = Application.EnableEvents
    oldAlerts = Application.DisplayAlerts
    On Error GoTo Failed
    Set form = WS(MAIN)
    If ThisWorkbook.ReadOnly Then MsgBox UI(14), vbExclamation: Exit Sub
    If Len(ThisWorkbook.Path) = 0 Then MsgBox UI(15), vbExclamation: Exit Sub
    If Not ValidForm() Then Exit Sub
    If MsgBox(UI(16), vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    If Not Application.Dialogs(xlDialogPrinterSetup).Show Then Exit Sub
    BusyPrinting = True
    Application.EnableEvents = False
    n = NextNumber()
    archiveName = "RET_" & Format$(n, "000000")
    WS(SETTINGS).Range("D1").Value = n
    form.Calculate
    form.Copy After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count)
    Set snapshot = ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count)
    snapshot.Name = archiveName
    snapshot.Tab.Color = RGB(38, 135, 100)
    snapshot.Range("A1:M38").Copy
    snapshot.Range("A1:M38").PasteSpecial xlPasteValues
    Application.CutCopyMode = False
    snapshot.Range("I7").Value = Now
    snapshot.Range("I7").NumberFormat = "yyyy-mm-dd hh:mm"
    snapshot.Range("L9").Value = "#" & CStr(n)
    For shapeIndex = snapshot.Shapes.count To 1 Step -1
        If Left$(snapshot.Shapes(shapeIndex).Name, 4) = "btn_" Or snapshot.Shapes(shapeIndex).Type = msoFormControl Then snapshot.Shapes(shapeIndex).Delete
    Next shapeIndex
    snapshot.Range("A11:M11").ClearContents
    snapshot.Range("AA:AB").ClearContents
    snapshot.Range("A1:M38").Validation.Delete
    snapshot.Cells.Locked = True
    snapshot.Protect Password:="", DrawingObjects:=True, Contents:=True, Scenarios:=True
    Set log = ThisWorkbook.Worksheets("Archive")
    logRow = LastRow(log, 9) + 1
    If logRow < 4 Then logRow = 4
    log.Cells(logRow, 1).Value = n
    log.Cells(logRow, 2).Value = Now
    log.Cells(logRow, 3).NumberFormat = "@"
    log.Cells(logRow, 3).Value = form.Range("A9").Value
    log.Cells(logRow, 4).Value = form.Range("B9").Value
    log.Cells(logRow, 5).Value = form.Range("J9").Value
    log.Cells(logRow, 6).Value = form.Range("G38").Value
    log.Cells(logRow, 7).Value = form.Range("H38").Value
    log.Cells(logRow, 8).Value = form.Range("I38").Value
    log.Cells(logRow, 9).Value = UI(17)
    log.Hyperlinks.Add Anchor:=log.Cells(logRow, 10), Address:="", SubAddress:="'" & archiveName & "'!A1", TextToDisplay:=archiveName
    ThisWorkbook.Save
    archiveSaved = True
    form.Range("A9").MergeArea.ClearContents
    form.Range("B9").MergeArea.ClearContents
    form.Range("G12").MergeArea.ClearContents
    form.Range("F15:F37").ClearContents
    form.Range("D12").MergeArea.ClearContents
    form.Range("B15:E37,G15:J37,L15:M37").ClearContents
    WS(SETTINGS).Range("D1").Value = n + 1
    form.Calculate
    form.Activate
    ThisWorkbook.Save
    On Error GoTo PrintFailed
    snapshot.PrintOut Copies:=1
    log.Cells(logRow, 9).Value = UI(18)
    ThisWorkbook.Save
    Application.EnableEvents = oldEvents
    BusyPrinting = False
    form.Activate
    MsgBox UI(19) & " " & archiveName & vbCrLf & UI(20), vbInformation
    Exit Sub
PrintFailed:
    errorText = Err.Description
    On Error Resume Next
    log.Cells(logRow, 9).Value = UI(21)
    ThisWorkbook.Save
    Application.EnableEvents = oldEvents
    BusyPrinting = False
    form.Activate
    On Error GoTo 0
    MsgBox UI(22) & " " & archiveName & vbCrLf & errorText, vbExclamation
    Exit Sub
Failed:
    errorText = Err.Description
    On Error Resume Next
    If Not archiveSaved Then
        Application.DisplayAlerts = False
        If Not snapshot Is Nothing Then snapshot.Delete
        If logRow >= 4 Then log.Rows(logRow).Delete
    End If
    Application.DisplayAlerts = oldAlerts
    Application.EnableEvents = oldEvents
    BusyPrinting = False
    If Not form Is Nothing Then form.Activate
    On Error GoTo 0
    If archiveSaved Then
        MsgBox UI(23) & " " & archiveName & vbCrLf & errorText, vbExclamation
    Else
        MsgBox UI(24) & vbCrLf & errorText, vbExclamation
    End If
End Sub

Public Sub ReprintArchive()
    Dim log As Worksheet, archiveName As String, Sh As Worksheet
    Dim oldEvents As Boolean, errorText As String
    Set log = ThisWorkbook.Worksheets("Archive")
    If ActiveSheet.Name <> log.Name Or ActiveCell.Row < 4 Then MsgBox UI(25), vbInformation: Exit Sub
    archiveName = CStr(log.Cells(ActiveCell.Row, 10).Value)
    If Len(archiveName) = 0 Then Exit Sub
    On Error GoTo Failed
    Set Sh = ThisWorkbook.Worksheets(archiveName)
    If Not Application.Dialogs(xlDialogPrinterSetup).Show Then Exit Sub
    oldEvents = Application.EnableEvents
    Application.EnableEvents = False
    BusyPrinting = True
    Sh.PrintOut Copies:=1
    Application.EnableEvents = oldEvents
    BusyPrinting = False
    log.Cells(ActiveCell.Row, 9).Value = UI(18)
    ThisWorkbook.Save
    Exit Sub
Failed:
    errorText = Err.Description
    If BusyPrinting Then Application.EnableEvents = oldEvents
    BusyPrinting = False
    MsgBox UI(26) & vbCrLf & errorText, vbExclamation
End Sub

